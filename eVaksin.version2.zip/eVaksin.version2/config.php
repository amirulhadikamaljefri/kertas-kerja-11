<!--Membuat sambungan ke db-->
<?php
    $connect = mysqli_connect('localhost', 'root', '', 'evaksin') or die('Failed to connect to db....') ;
//sila lengkapkan kod aturcara

?>

